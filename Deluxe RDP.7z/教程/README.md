你好，

请务必完全禁用Windows Defender及其保护功能，因为它们可能会影响工具的正常运行。

禁用Windows Defender的步骤如下：
a. 以管理员身份运行DefenderRemover程序。
b. 在提示时，输入 'Y' 并按回车键。
c. 等待Windows重新启动。

现在，要使用该工具，请以管理员身份运行它。

祝您使用愉快！

此版本完全干净；您可以放心在个人计算机上使用。

问候

工具/支持: @DSASInject